package com.example.resourceapp

data class ListItem (
        var ItemText :String
        )