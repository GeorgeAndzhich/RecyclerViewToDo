package com.example.resourceapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var rvDo = findViewById<RecyclerView>(R.id.recyclerView)
        var button = findViewById<Button>(R.id.button2)
        var etAdd = findViewById<EditText>(R.id.editTextTextPersonName)
        var todoList = mutableListOf(
                ListItem("Do the laundry"),
                ListItem("Wash the dishes"),
                ListItem("Feed the cat")
        )
        // Fill RecyclerView with items

        val adapter = Adapter(todoList)
         rvDo.adapter= adapter
        rvDo.layoutManager = LinearLayoutManager(this)

        button.setOnClickListener{
            val title = etAdd.text.toString()
            val item = ListItem(title)
            adapter.notifyDataSetChanged()
            todoList.add(item)
            adapter.notifyItemInserted(todoList.size - 1)
        }

    }
}