package com.example.resourceapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class Adapter (var items : List<ListItem>):RecyclerView.Adapter<Adapter.ViewHolder>() {

    inner class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder { // Inflate the layout
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) { // Bind the data to our items.
        holder.itemView.apply {
            var text = R.id.textView3.toString()
            var checked = R.id.button
            text = items[position].ItemText

        }
    }

    override fun getItemCount(): Int {
      return items.size
    }
}